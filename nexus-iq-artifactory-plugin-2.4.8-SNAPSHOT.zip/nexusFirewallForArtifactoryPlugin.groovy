/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import java.util.concurrent.locks.ReentrantReadWriteLock

import com.sonatype.iq.artifactory.safeMode.SafeModeNexusFirewallForArtifactory

import groovy.json.JsonOutput
import groovy.transform.Field
import org.apache.http.HttpStatus
import org.artifactory.exception.CancelException
import org.artifactory.fs.ItemInfo
import org.artifactory.repo.RepoPath
import org.artifactory.repo.Repositories
import org.artifactory.request.Request

import static java.lang.String.format

final String VERIFY_INIT_TIMEOUT = 'Verification of initial state failed to complete in a timely fashion'

final String VERIFY_EXCEPTION = 'verifyInit failed with exception: '

@Field final ReentrantReadWriteLock configReloadLock = new ReentrantReadWriteLock()

@Field NexusFirewallForArtifactory nexusFirewallForArtifactory

@Field Repositories repositoriesApi

@Field Long lastPropertiesFileTimestamp

// We need to stop the ConfigurationMonitor in case the plugin is reloaded.
// This can happen when:
//   - Jfrog Artifactory reloads the plugins
//   - The integration tests create a new plugin instance
ConfigurationMonitor.stop()

initPlugin(repositories)

ConfigurationMonitor.start(this)

executions {
  /**
   * This will return a summary for the Firewall policy evaluation for a particular repository
   *
   * This can be triggered with the following curl command:
   * curl -u admin "http://ARTIFACTORY_SERVER/artifactory/api/plugins/execute/firewallEvaluationSummary?params=repo=maven-central"
   **/
  firewallEvaluationSummary(httpMethod: 'GET', groups: ['readers']) { Map<String, List<String>> params ->
    this.configReloadLock.readLock().lock()
    try {
      if (!params.repo || params.repo.size() != 1) {
        status = 500
        message = 'Must supply a single repo name as a query parameter, i.e. ?params=repo=maven-central'
        return
      }

      try {
        message = JsonOutput.toJson(this.nexusFirewallForArtifactory.getFirewallEvaluationSummary(params.repo.get(0)))
        status = 200
      }
      catch (e) {
        status = 500
        message = e.message
      }
    }
    finally {
      this.configReloadLock.readLock().unlock()
    }
  }

  /**
   * Return the plugin version
   *
   * curl -u admin "http://ARTIFACTORY_SERVER/artifactory/api/plugins/execute/firewallVersion"
   **/
  firewallVersion(httpMethod: 'GET', groups: ['readers']) { Map<String, List<String>> params ->
    try {
      message = JsonOutput.toJson([version: nexusFirewallForArtifactory.getPluginVersion()])
    }
    catch (e) {
      message = e.message
    }
  }
}

download {
  beforeDownload { Request request, RepoPath repoPath ->
    this.configReloadLock.readLock().lock()
    try {
      runHandlerWithInitialisation(
          runOnceBeforeAllHandlers: { asSystem { this.nexusFirewallForArtifactory.verifyInit() } },
          handler: { this.nexusFirewallForArtifactory.beforeDownloadHandler(repoPath) },
          onRunOnceBeforeAllHandlersFailure: {
            this.log.error('beforeDownloadHandler - ' + it ? VERIFY_EXCEPTION : VERIFY_INIT_TIMEOUT, it)
            throw new CancelException(
                format("Download of '%s' cancelled as firewall is not fully initialized", repoPath), it,
                HttpStatus.SC_INTERNAL_SERVER_ERROR)
          }
      )
    }
    finally {
      this.configReloadLock.readLock().unlock()
    }
  }

  /**
   * Provide an alternative download content, by setting new values for the inputStream and size context variables.
   *
   * Context variables:
   * inputStream (java.io.InputStream) - a new stream that provides the response content. Defaults to null.
   * size (long) - the size of the new content (helpful for clients processing the response). Defaults to -1.
   *
   * Closure parameters:
   * repoPath (org.artifactory.repo.RepoPath) - a read-only parameter of the original request RepoPath.
   */
  altRemoteContent { repoPath ->
    this.configReloadLock.readLock().lock()

    try {
      runHandlerWithInitialisation(
          runOnceBeforeAllHandlers: { asSystem { this.nexusFirewallForArtifactory.verifyInit() } },
          handler: {
            byte[] newContent = this.nexusFirewallForArtifactory.altRemoteContentHandler(ctx, repoPath)
            if (newContent != null) {
              size = newContent.length
              inputStream = new ByteArrayInputStream(newContent)
            }
          },
          onRunOnceBeforeAllHandlersFailure: {
            this.log.error('altRemoteContentHandler - ' + it ? VERIFY_EXCEPTION : VERIFY_INIT_TIMEOUT, it)
            throw new CancelException(
                format("Download of '%s' cancelled as firewall is not fully initialized", repoPath),
                HttpStatus.SC_INTERNAL_SERVER_ERROR)
          }
      )
    }
    finally {
      this.configReloadLock.readLock().unlock()
    }
  }

  /**
   * Provides an alternative download path under the same remote repository, by setting a new value to the path
   * variable.
   *
   * Context variables:
   * path (java.lang.String) - the new path value. Defaults to the originalRepoPath's path.
   *
   * Closure parameters:
   * repoPath (org.artifactory.repo.RepoPath) - a read-only parameter of the original request RepoPath.
   */
  altRemotePath { repoPath ->
    this.configReloadLock.readLock().lock()

    try {
      runHandlerWithInitialisation(
          runOnceBeforeAllHandlers: { asSystem { this.nexusFirewallForArtifactory.verifyInit() } },
          handler: {
            asSystem { this.nexusFirewallForArtifactory.altRemotePathHandler(repoPath) }
          },
          onRunOnceBeforeAllHandlersFailure: {
            this.log.error('altRemotePathHandler - ' + it ? VERIFY_EXCEPTION : VERIFY_INIT_TIMEOUT, it)
          }
      )
    }
    finally {
      this.configReloadLock.readLock().unlock()
    }
  }
}

storage {
  beforePropertyCreate { ItemInfo item, String name, String[] values ->
    nexusFirewallForArtifactory.propertyEventHandler(name)
  }
  beforePropertyDelete { ItemInfo item, String name ->
    nexusFirewallForArtifactory.propertyEventHandler(name)
  }
  afterDelete { ItemInfo item ->
    this.configReloadLock.readLock().lock()
    try {
      runHandlerWithInitialisation(
        runOnceBeforeAllHandlers: { asSystem { this.nexusFirewallForArtifactory.verifyInit() }},
        handler: { nexusFirewallForArtifactory.afterDeleteHandler(item.repoPath) },
        onRunOnceBeforeAllHandlersFailure: { this.log.error('afterDeleteHandler - ' + it ? VERIFY_EXCEPTION :
            VERIFY_INIT_TIMEOUT, it) }
      )
    }
    finally {
      this.configReloadLock.readLock().unlock()
    }
  }
}

/**
 * A job definition.
 * The first value is a unique name for the job.
 * Job runs are controlled by the provided interval or cron expression, which are mutually exclusive.
 * The actual code to run as part of the job should be part of the job's closure.
 *
 * Parameters:
 * delay (long) - An initial delay in milliseconds before the job starts running (not applicable for a cron job).
 * interval (long) -  An interval in milliseconds between job runs.
 * cron (java.lang.String) - A valid cron expression used to schedule job runs
 * **/
jobs {
  namespaceConfusionProtectionJob(
      cron: this.nexusFirewallForArtifactory.getNamespaceConfusionProtectionJobCronExpression())
      {
        this.configReloadLock.readLock().lock()
        try {
          runHandlerWithInitialisation(
              runOnceBeforeAllHandlers: { this.nexusFirewallForArtifactory.verifyInit() },
              handler: { this.nexusFirewallForArtifactory.namespaceConfusionProtectionJobHandler() },
              onRunOnceBeforeAllHandlersFailure: { this.log.error('namespaceConfusionProtectionJobHandler - ' +
                  it ? VERIFY_EXCEPTION : VERIFY_INIT_TIMEOUT, it) }
          )
        }
        finally {
          this.configReloadLock.readLock().unlock()
        }
      }

  initializationJob(
      cron: this.nexusFirewallForArtifactory.getInitializationJobCronExpression())
      {
        this.configReloadLock.readLock().lock()
        try {
          runHandlerWithInitialisation(
              runOnceBeforeAllHandlers: { this.nexusFirewallForArtifactory.verifyInit() },
              handler: { this.nexusFirewallForArtifactory.initializationJobHandler() },
              onRunOnceBeforeAllHandlersFailure: { this.log.error('initializationJobHandler - ' +
                  it ? VERIFY_EXCEPTION : VERIFY_INIT_TIMEOUT, it) }
          )
        }
        finally {
          this.configReloadLock.readLock().unlock()
        }
      }

}

private runHandlerWithInitialisation(Map params) {
  Exception initializationException = null
  if (this.nexusFirewallForArtifactory.isInitializationRequired()) {
    try {
      params.runOnceBeforeAllHandlers()
    } catch(Exception e) {
      initializationException = e
    }
  }
  if (this.nexusFirewallForArtifactory.isReady() && initializationException == null) {
    params.handler()
  }
  else {
    params.onRunOnceBeforeAllHandlersFailure(initializationException)
  }
}

private String getArtifactoryVersion() {
  String version
  try {
    // This is used up to Artifactory 7.38 or 7.39.
    // We can remove it when the oldest supported version is 7.39 (around 20-Dec-2023).
    version = ctx.versionProvider?.running?.versionName
  }
  catch (MissingPropertyException e) {
    try {
      version = ctx.versionProvider?.runningServiceVersion?.versionName
    }
    catch (MissingPropertyException e1) {
      log.debug("Unable to get JFrog Artifactory version. Incompatible API.")
      version = 'unknown'
    }
  }
  log.debug("Found JFrog Artifactory version: ${version}")
  return version
}

private void initPlugin(Repositories repositories) {
  long start = System.currentTimeMillis()
  log.info('Initializing the FirewallForArtifactory plugin.')
  try {
    repositoriesApi = repositories

    nexusFirewallForArtifactory = new DefaultNexusFirewallForArtifactory(log, ctx.artifactoryHome.pluginsDir,
        repositories, searches, getArtifactoryVersion())
  }
  catch (MissingPropertiesException | InvalidPropertiesException e) {
    nexusFirewallForArtifactory = new SafeModeNexusFirewallForArtifactory(e.message, log)
  }
  catch (e) {
    log.error(e.message)
    throw e
  }
  nexusFirewallForArtifactory.init()

  lastPropertiesFileTimestamp = getPropertiesFileTimestamp()
  log.info("Initialized the FirewallForArtifactory plugin in ${System.currentTimeMillis() - start} ms.")
}

private void reloadConfigIfNeeded() {
  if (getPropertiesFileTimestamp() != lastPropertiesFileTimestamp) {
    log.info('Detected FirewallForArtifactory plugin config change. Reloading the configuration.')
    configReloadLock.writeLock().lock()
    try {
      initPlugin(repositoriesApi)
      jobs {
        initializationJob(
            cron: this.nexusFirewallForArtifactory.getInitializationJobCronExpression())
            {
              this.configReloadLock.readLock().lock()
              try {
                runHandlerWithInitialisation(
                    runOnceBeforeAllHandlers: { this.nexusFirewallForArtifactory.verifyInit() },
                    handler: { this.nexusFirewallForArtifactory.initializationJobHandler() },
                    onRunOnceBeforeAllHandlersFailure: { this.log.error('initializationJobHandler - ' +
                        it ? VERIFY_EXCEPTION : VERIFY_INIT_TIMEOUT, it) }
                )
              }
              finally {
                this.configReloadLock.readLock().unlock()
              }
            }
      }
    }
    catch (e) {
      log.error('Error while reloading the FirewallForArtifactory plugin config: {}', e.message, e)
    }
    finally {
      configReloadLock.writeLock().unlock()
    }
  }
}

private Long getPropertiesFileTimestamp() {
  return FirewallProperties.getPropertiesFile().isFile() ? FirewallProperties.getPropertiesFile().lastModified() : null
}
